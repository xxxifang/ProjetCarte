package jeucarte;

public enum EnumT {

	rocl,cc,cl,rol,ro,hcl,hc,hro,hr,ho
}
